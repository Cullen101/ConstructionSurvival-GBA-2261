Hello and Welcome!
This is my game Construction Survival!

--INSTRUCTIONS--
There are enemies swarming your construction site! Run away and survive! Even if they or you fall off, you will start back up at the top of the level.
Avoid the enemies or you will get hurt and the level will start again, but beware, you can only get hit 3 times or you will lose!
Shoot and kill five enemies to Win!

--ITEMS--
There are items (shaped like HardHats) that imbue you with special power!
Running over this will grant you a special ability!
For now, the only power up is to stop time ONCE.

--STOPPING TIME--
Press B to stop time. Here all enemies freeze except you. You cannot shoot because you have frozen time.
Press B a second time, to unfreeze and have time resume. Your bullet will fire in the direction you last moved towards before stopping time.
NOTE: YOU CANNOT SHOOT WHILE TIME IS FROZEN

--CONTROLS--
Press UP to jump! The longer you hold it the higher you will go, however, if you hit a ceiling, you will start falling immediently.
Press LEFT and RIGHT to move side to side.
Press A to shoot your gun! Be careful, you can only have 1 bullet out at a time
Press B to use a powerup

--BEWARE--
If you fall off of the map below, you will take a hit!
Your nailgun takes a long time to reload, so watch out!

--MOST OF ALL--
HAVE FUN! Its a game anyway :D