//Prototypes
void initGame();
void updateGame();
void drawGame();